// import { Injectable } from '@angular/core';
// import { CanActivate, RouterStateSnapshot, ActivatedRouteSnapshot, Router } from '@angular/router';
// import { HttpClient } from '@angular/common/http';

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthService implements CanActivate{

//   constructor(private router:Router, public http: HttpClient) { }

//   canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)
//   {
//    if(sessionStorage.getItem("userId"))
//    {
//      return true;
//    }
//    else
//    {
//      this.router.navigate(['/login']);
//      return false;  
//    }
//   }
// }

import { Injectable } from '@angular/core';
import { CanActivate, RouterStateSnapshot, ActivatedRouteSnapshot, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { RegisterComponent } from 'src/app/Components/User/register/register.component';

@Injectable({
  providedIn: 'root'
})
export class AuthService implements CanActivate{

  constructor(private router:Router, public http: HttpClient,public dialog:MatDialog) { }

  check()
  {
    if(sessionStorage.getItem("userId")!=null)
    {
      return true;
    }
    return false;
  }

  checkRole()
  {
    if(sessionStorage.getItem("role")=="Admin")
    {
      return true;
    }
    return false;
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)
  {
   if(sessionStorage.getItem("userId"))
   {
     return true;
   }
   else
   {
      this.dialog.open(RegisterComponent, {
      width: '500px',
      disableClose: true,
      data: {
        animal: 'panda',
      },
    });
     return false;  
   }
  }
}
