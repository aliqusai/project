export class Users{
    signUpName:string="";
    signUpEmail:string="";
    signUpPassword1:string="";
    signUpPassword2:string="";
}