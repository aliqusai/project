import { Component, OnInit } from '@angular/core';
import { QuizService } from 'src/app/services/user/quiz.service';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.scss'],
})
export class SliderComponent implements OnInit {
  QuizNames: any;
  myControl = new FormControl();
  constructor(private service: QuizService) {
    this.service.getQuizNames().subscribe((data) => {
      this.QuizNames = data;
    });
  }

  ngOnInit() {}
}
