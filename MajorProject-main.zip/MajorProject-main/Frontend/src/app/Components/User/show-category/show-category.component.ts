import { Component, OnInit } from '@angular/core';

import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { ShowCategoryService } from 'src/app/services/user/show-category.service';
import { QuizService } from 'src/app/services/user/quiz.service';
import { Router } from '@angular/router';
import { GetQuizUserService } from 'src/app/services/admin/get-quiz-user.service';

@Component({
  selector: 'app-show-category',
  templateUrl: './show-category.component.html',
  styleUrls: ['./show-category.component.scss'],
})
export class ShowCategoryComponent implements OnInit {
  categoryName: any;
  QuizNames: any;
  QuizNamesForSearch: any = [];
  selectedQuiz: any;
  inputText: any;

  showQuiz: any;

  myControl = new FormControl();
  options: string[] = this.QuizNamesForSearch;
  filteredOptions: Observable<string[]>;

  ngOnInit() {
    this.getCategoryName();
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map((value) => this._filter(value))
    );
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter((option) =>
      option.toLowerCase().includes(filterValue)
    );
  }

  constructor(
    private service: QuizService,
    private route: Router,
    private displayQuizService: ShowCategoryService,
    private getQuiz: GetQuizUserService
  ) {
    this.service.getQuizNames().subscribe((data) => {
      this.QuizNames = data;
      for (let i = 0; i < this.QuizNames.length; i++) {
        this.QuizNamesForSearch.push(this.QuizNames[i].quizName);
      }
    });
  }
  go() {

    this.getQuiz.getQuiz(this.selectedQuiz).subscribe((data) => {
      this.showQuiz = data;
      sessionStorage.setItem('categoryId', this.showQuiz[0].categoryId);
      this.route.navigate(['quizLists/' + this.showQuiz[0].quizId]);
    });
  }

  getCategoryName() {
    return this.displayQuizService.getCategoryName().subscribe((que) => {
      this.categoryName = que;
    });
  }
}
