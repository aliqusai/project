import { Component, OnInit } from '@angular/core';
import { FeedbackService } from 'src/app/services/admin/feedback.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss'],
})
export class FeedbackComponent implements OnInit {
  feedback: any;
  constructor(private service: FeedbackService) {}

  ngOnInit(): void {
    this.service.getAllFeedback().subscribe((data) => {
      this.feedback = data;
    });
  }
}
