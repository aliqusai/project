import { Component, OnInit } from '@angular/core';
import { Question } from 'src/app/Class/question';
import { AddQuizService } from 'src/app/services/admin/add-quiz.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-quiz',
  templateUrl: './add-quiz.component.html',
  styleUrls: ['./add-quiz.component.scss'],
})
export class AddQuizComponent implements OnInit {
  questions = new Question();
  quizName: any;
  categoryName: any;
  typeName: any;
  submitted = false;
  categoryId: any;
  constructor(
    private addQuestionService: AddQuizService,
    private route: Router
  ) {}

  ngOnInit(): void {
    this.getCategoryName();
    this.getTypeName();
  }

  catName: string = ' ';
  getId(event: any) {
    this.catName = event.target.value;
    this.getQuizName(this.catName);
  }
  addQuestion() {
    this.submitted = true;
    this.addQuestionService.addQuestion(this.questions).subscribe();
    this.route.navigate(['admin']);
    alert("Question added sucessfully...")
  }

  getQuizName(catname: any) {
    return this.addQuestionService.getQuizName(catname).subscribe((que) => {
      this.quizName = que;
    });
  }

  getCategoryName() {
    return this.addQuestionService.getCategoryName().subscribe((que) => {
      this.categoryName = que;
    });
  }

  getTypeName() {
    return this.addQuestionService.getTypeName().subscribe((que) => {
      this.typeName = que;
    });
  }
}
