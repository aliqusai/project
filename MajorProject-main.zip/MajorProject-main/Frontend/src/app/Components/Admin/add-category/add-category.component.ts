import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.scss'],
})
export class AddCategoryComponent implements OnInit {
  public selectedFile: any;
  public category = { categoryName: '', description: '' };
  constructor(private http: HttpClient, private route: Router) {}

  ngOnInit(): void {}
  fileUpload(event: any) {
    this.selectedFile = event.target.files[0];
  }
  fileUploadHandler(event: any) {
    event.preventDefault();
    const data: FormData = new FormData();
    data.append('uploadfile', this.selectedFile);
    data.append('categoryName', this.category.categoryName);
    data.append('description', this.category.description);

    this.http
      .post('http://localhost:8080/api/cat', data)
      .subscribe((res: any) => {
        if (res['status'] === 200) {
        }
      });

    this.route.navigate(['admin/categoryList']);
  }
}
