import { Component, OnInit } from '@angular/core';
import { FeedbackService } from 'src/app/services/admin/feedback.service';
import {
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
  MatSnackBar,
} from '@angular/material/snack-bar';
import { RegisterService } from 'src/app/services/user/register.service';
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent implements OnInit {
  currentId:any;
  fedbackList:any;
  flag:boolean=false;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(private service: FeedbackService,private _snackBar: MatSnackBar,private sObj:RegisterService) {}

  ngOnInit(): void {}

  bad() {
    this.flag=false;
    this.service.getAllFeedback().subscribe((data)=>{
      this.fedbackList=data;
     
      for(let i=0;i<this.fedbackList.length;i++)
      {
        if(sessionStorage.getItem("userId")==this.fedbackList[i].userId)
        {
          this.flag=true;
          this.service.updateFeedback('bad').subscribe();
          break;
        }
      
      }
      if(this.flag==false)
      {
        this.service.postFeedback('bad').subscribe();
        this.flag=true;
      }
    })
    this._snackBar.open('Thank you for your feedback', ' ', {
      duration: 2000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }

  moderate() {
    this.flag=false;
    this.service.getAllFeedback().subscribe((data)=>{
      this.fedbackList=data;
      console.log(this.fedbackList);
      for(let i=0;i<this.fedbackList.length;i++)
      {
        if(sessionStorage.getItem("userId")==this.fedbackList[i].userId)
        {
          this.flag=true;
          this.service.updateFeedback('moderate').subscribe();
          break;
        }
      
      }
      if(this.flag==false)
      {
        this.service.postFeedback('moderate').subscribe();
        this.flag=true;
      }
    })
    this._snackBar.open('Thank you for your feedback', ' ', {
      duration: 2000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }
  good() {
    this.flag=false;
    this.service.getAllFeedback().subscribe((data)=>{
      this.fedbackList=data;
      console.log(this.fedbackList);
      for(let i=0;i<this.fedbackList.length;i++)
      {
        if(sessionStorage.getItem("userId")==this.fedbackList[i].userId)
        {
          this.flag=true;
          this.service.updateFeedback('good').subscribe();
          break;
        }
      
      }
      if(this.flag==false)
      {
        this.service.postFeedback('good').subscribe();
        this.flag=true;
      }
    })
    this._snackBar.open('Thank you for your feedback', ' ', {
      duration: 2000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }
  deleteFeed()
  {
    this.service.deleteFeedback().subscribe();
  }
  goup() {
    window.scrollTo(0, 0);
  }
}