import { Component, OnInit } from '@angular/core';
import { QuizService } from 'src/app/services/user/quiz.service';

@Component({
  selector: 'app-quiz-list',
  templateUrl: './quiz-list.component.html',
  styleUrls: ['./quiz-list.component.scss'],
})
export class QuizListComponent implements OnInit {
  quizList: any;
  constructor(private quizService: QuizService) {}

  ngOnInit(): void {
    this.getQuizInfo();
  }

  getQuizInfo() {
    return this.quizService.getQuizNames().subscribe((list: any) => {
      this.quizList = list;
    });
  }
}
