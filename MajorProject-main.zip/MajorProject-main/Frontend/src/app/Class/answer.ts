export class correctAnswers{
    id:any;
    userAnswer:string;

    constructor(id:any,ans:any)
    {
        this.id=id;
        this.userAnswer=ans;
    }
}
