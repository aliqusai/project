const db = require("../models");
const fs = require("fs");
  exports.addQuestion = (req,res)=>{
    db.sequelize.query("insert into questionarie(questionId,question,option1,option2,option3,option4,answer,quizId,categoryId,typeId) values (?,?,?,?,?,?,?,(select quizId from quiz where quizName=?),(select categoryId from categories where categoryName=?),(select typeId from questionType where typeName=?))",
    {replacements: [req.body.questionId,req.body.question,req.body.option1,
        req.body.option2,req.body.option3,req.body.option4,
        req.body.answer,req.body.quizName,req.body.categoryName,req.body.typeName],type: db.sequelize.QueryTypes.INSERT }).then(data=>{
        res.send(data);
      });
  }


  exports.getQuizNameByName = (req,res)=>{
    db.sequelize.query("select * from quiz where quizName=?",
    {replacements: [req.params.quizName],type: db.sequelize.QueryTypes.SELECT }).then(data=>{
        res.send(data);
      });
 }

  exports.getCategoryName = (req,res)=>{
    db.sequelize.query("select * from categories",{type: db.sequelize.QueryTypes.SELECT }).then(data=>{
        res.send(data);
      });
  }

  exports.getTypeName = (req,res)=>{
    db.sequelize.query("select * from questionType",{type: db.sequelize.QueryTypes.SELECT }).then(data=>{
        res.send(data);
      });
  }

  //Insert Data
  exports.insert=(req,res)=>{ 
    db.sequelize.query("insert into quiz(quizName,categoryId,duration,count) values (?,?,?,?)",
    {replacements: [ req.body.quizName,req.body.categoryId,req.body.duration,req.body.count],type: db.sequelize.QueryTypes.INSERT }).then(data=>{
        res.send(data);
      });
  }

  exports.getQuizNameById = (req,res)=>{
    db.sequelize.query("select * from quiz where categoryId=?", 
    {replacements: [ req.params.id],type: db.sequelize.QueryTypes.SELECT }).then(data=>{
       res.send(data);
     })
    }

      exports.getQuiz = (req,res)=>{
      db.sequelize.query("select * from quiz",{type: db.sequelize.QueryTypes.SELECT }).then(data=>{
        res.send(data);
      });
    }

    exports.getQuizNames = (req, res) => {
      db.sequelize
        .query(
          "select quiz.quizName from quiz,categories c where c.categoryName=? and quiz.categoryId=c.categoryId ",
          {
            replacements: [req.params.catname],
            type: db.sequelize.QueryTypes.SELECT,
          }
        )
        .then((data) => {
          res.send(data);
        });
    };
    

    const Image = db.quiz;

// Upload a Multipart-File then saving it to MySQL database
exports.insertQuiz = (req, res) => {
  Image.create({
    type: req.file.mimetype,
    name: req.file.originalname,
    data: fs.readFileSync("D:/Dipali-BT-main/Frontend/src/" + "assets/category/" + req.file.filename),
    quizName: req.body.quizName,
    categoryId: req.body.categoryId,
    duration: req.body.duration,
    count: req.body.count,
 
  }).then((image) => {
    try {
      fs.writeFileSync("D:/Dipali-BT-main/Frontend/src/" + "assets/category/" + image.name, image.data);

      // exit node.js app
      res.json({ msg: "File uploaded successfully!", file: req.file });
    } catch (e) {
      res.json({ err: e });
    }
  });
};
