const db = require("../models");
exports.getByCategory = (req,res)=>{
    db.sequelize.query("select * from categories where categoryId =?",{replacements: [req.params.id], type: db.sequelize.QueryTypes.SELECT }).then(data=>{
        res.send(data);
      });
  }

  exports.getQuestionarie = (req,res)=>{
    db.sequelize.query("select * from questionarie where quizId =? and categoryId=? ORDER BY RAND() LIMIT 10",
    {replacements: [req.query.quizId, req.query.categoryId], type: db.sequelize.QueryTypes.SELECT }).then(data=>{
        res.send(data);
      });
  }

  exports.getByQuizCategory = (req,res)=>{
    db.sequelize.query("select * from quiz where categoryId =?",{replacements: [req.params.id], type: db.sequelize.QueryTypes.SELECT }).then(data=>{
        res.send(data);
      });
  }