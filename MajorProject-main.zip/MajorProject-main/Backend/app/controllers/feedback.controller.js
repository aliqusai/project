// const db = require("../models");
// exports.insert=(req,res)=>{
//   db.sequelize.query("insert into feedback (userId,experience) values(?,?)",
//   {replacements: [ req.body.userId,req.body.experience],
//     type: db.sequelize.QueryTypes.INSERT }).then(data=>{
//       res.send(data); 
//     });
// }

// exports.delete=(req,res)=>{
//     db.sequelize.query("delete from feedback where userId=?",
//     {replacements: [req.params.userId],type: db.sequelize.QueryTypes.DELETE }).then(data=>{
//         res.send(data);
//       });
//   }

//   exports.getFeedback = (req,res)=>{
//     db.sequelize.query("select f.experience, u.name from feedback f inner join users u on u.userId=f.userId",{type: db.sequelize.QueryTypes.SELECT }).then(data=>{
//         res.send(data);
//       });
//   }

const db = require("../models");
exports.insert=(req,res)=>{
  db.sequelize.query("insert into feedback (userId,experience) values(?,?)",
  {replacements: [ req.body.userId,req.body.experience],
    type: db.sequelize.QueryTypes.INSERT }).then(data=>{
      res.send(data); 
    });
}

exports.delete=(req,res)=>{
    db.sequelize.query("delete from feedback where userId=?",
    {replacements: [req.params.userId],type: db.sequelize.QueryTypes.DELETE }).then(data=>{
        res.send(data);
      });
  }

  exports.getFeedback = (req,res)=>{
    db.sequelize.query("select f.experience,u.userId, u.name from feedback f inner join users u on u.userId=f.userId",{type: db.sequelize.QueryTypes.SELECT }).then(data=>{
        res.send(data);
      });
  }

  exports.updateFeedback = (req, res) => {
    db.sequelize
      .query("update feedback set experience=? where userId=? ", {
        replacements: [req.body.experience, req.body.userId],
        type: db.sequelize.QueryTypes.UPDATE,
      })
      .then((data) => {
        res.send(data);
      });
  };


