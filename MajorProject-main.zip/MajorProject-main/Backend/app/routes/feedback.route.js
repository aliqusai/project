// module.exports = app => {
//     const feedback = require("../controllers/feedback.controller.js");
//     var router = require("express").Router();
//     router.post("/", feedback.insert);
//     router.delete("/:userId", feedback.delete);
//     router.get("/list", feedback.getFeedback);
//     app.use('/api/feedback', router);
//   };

module.exports = app => {
  const feedback = require("../controllers/feedback.controller.js");
  var router = require("express").Router();
  router.post("/", feedback.insert);
  router.delete("/:userId", feedback.delete);
  router.get("/list", feedback.getFeedback);
  router.put("/putt",feedback.updateFeedback);
  app.use('/api/feedback', router);
};